<?php

class MainController
{
    // Page d'accueil
    public function home()
    {
        require_once __DIR__ . '/../Model/Brand.php';
        $brandModel = new Brand();
        $brands = $brandModel->findAll();
        var_dump($brands);
        $this->render('home', ['brands' => $brands]);
    }

    // Page "About"
    public function about()
    {
        $this->render('about');
    }

    // Page 404
    public function notFound()
    {
        http_response_code(404);
        echo "404 - Page Not Found!";
    }

    public function catalogue()
    {
        $this->render('catalogue');
    }

    public function connexion()
    {
        $this->render('connexion');
    }
    public function inscription()
    {
        $this->render('inscription');
    }
    public function panier()
    {
        $this->render('panier');
    }

    // Méthode pour inclure une vue
    private function render($view, $data = [])
    {
        // Transmet les données aux vues
        extract($data);

        // Inclut la vue demandée
        $viewFile = __DIR__ . '/../views/' . $view . '.php';
        if (file_exists($viewFile)) {
            require_once '/../views/partials/header.php';
            require_once $viewFile;
            require_once '/../views/partials/footer.php';
        } else {
            echo "View not found: $view";
        }
    }
}
