        <h1>Home</h1>
        <p>Welcome to our website</p>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Architecto maxime quidem deserunt totam tempora consequuntur neque vero laborum. Quis facere repudiandae dolores necessitatibus repellendus dolorum amet, neque praesentium qui dignissimos?</p>
    </main>
    <footer>
        <p>&copy; 2021</p>
    </footer>
</body>

</html>