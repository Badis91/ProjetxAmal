<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catalogue</title>
</head>
<body>
   <?php require_once('partials/header.php'); ?>

   <main>
        <h1>Catalogue</h1>
        <p>Here is a list of our products</p>

        <article>
            <section>
                <fieldset>
                    <legend>Product 1</legend>
                    <img src="../image/téléchargement.jpg" alt="Product 1">
                    <p>Price: $10</p>
                    <button onclick="ajouterAuPanier('Product 1', 10)">Add to cart</button>
                </fieldset>
            </section>
            <section>
                <fieldset>
                    <legend>Product 2</legend>
                    <img src="../image/téléchargement.jpg" alt="Product 2">
                    <p>Price: $20</p>
                    <button onclick="ajouterAuPanier('Product 2', 20)">Add to cart</button>
                </fieldset>
            </section>
            <section>
                <fieldset>
                    <legend>Product 3</legend>
                    <img src="../image/téléchargement.jpg" alt="Product 3">
                    <p>Price: $30</p>
                    <button onclick="ajouterAuPanier('Product 3', 30)">Add to cart</button>
                </fieldset>
            </section>
            <section>
                <fieldset>
                    <legend>Product 4</legend>
                    <img src="../image/téléchargement.jpg" alt="Product 4">
                    <p>Price: $40</p>
                    <button onclick="ajouterAuPanier('Product 4', 40)">Add to cart</button>
                </fieldset>
            </section>
            <section>
                <fieldset>
                    <legend>Product 5</legend>
                    <img src="../image/téléchargement.jpg" alt="Product 5">
                    <p>Price: $50</p>
                    <button onclick="ajouterAuPanier('Product 5', 50)">Add to cart</button>
                </fieldset>
            </section>
            <!-- Ajoutez d'autres produits ici de la même manière -->
        </article>
    </main>

    <?php require_once('partials/footer.php'); ?>
</body>