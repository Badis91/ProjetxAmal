<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php require_once('partials/header.php'); ?>
    <main>
    <h1>Inscription</h1>
        <form action="inscription.php" method="POST">
            <label for="nom">Nom:</label>
            <input type="text" id="nom" name="nom" required>
            <label for="prenom">Prénom:</label>
            <input type="text" id="prenom" name="prenom" required>
            <label for="adresse">Adresse:</label>
            <input type="text" id="adresse" name="adresse" required>
            <label for="Numéro">Numéro:</label>
            <input type="text" id="Numéro" name="Numéro" required>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <a href="./connexion.html">Vous avez déjà un compte ?</a>
            <button type="submit">Inscription</button>
        </form>
    </main>
    <?php require_once('partials/footer.php'); ?>
</body>
</html>