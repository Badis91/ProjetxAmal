<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Website</title>
    <link rel="stylesheet" href="/public/css/catalogue.css">
    <link rel="stylesheet" href="/public/css/header.css">
    <link rel="stylesheet" href="/public/css/footer.css">
    <link rel="stylesheet" href="/public/css/panier.css">
    <link rel="stylesheet" href="/public/css/style.css">
</head>
<body>
<header>
        <nav>
            <ul>
                <img src="../images/product1.jpg" alt="logo">
            </ul>
            <ul>
                <a href="#">Home</a>
                <a href="./html/catalogue.html">Catalogue</a>
                <a href="./html/connexion.html">connexion</a>
                <a href="./html/inscription.html">inscription</a>
                <a href=".">Panier</a></li>
            </ul>
        </nav>
    </header>
