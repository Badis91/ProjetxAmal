<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php require_once('partials/header.php'); ?>
    <main>
        <h1>Panier</h1>
        <p>Here is a list of the products in your cart</p>
        <ul id="panier"></ul>
        <h2>Total: <span id="total"></span></h2>
    </main>
    <?php require_once('partials/footer.php'); ?>
</body>
</html>

<script>
        function afficherPanier() {
            let panier = JSON.parse(localStorage.getItem('panier')) || [];
            const listePanier = document.getElementById('panier');
            const totalElement = document.getElementById('total');
            listePanier.innerHTML = '';
            let total = 0;

            panier.forEach((article, index) => {
                const quantité = article.quantité || 1;
                const li = document.createElement('li');
                li.innerHTML = `
                    ${article.nom} - $${article.prix} 
                    <input type="number" min="1" value="${quantité}" onchange="modifierQuantité(${index}, this.value)">
                    <button onclick="supprimerArticle(${index})">Supprimer</button>
                `;
                listePanier.appendChild(li);
                total += article.prix * quantité;
            });

            totalElement.textContent = `$${total.toFixed(2)}`;
        }

        function supprimerArticle(index) {
            let panier = JSON.parse(localStorage.getItem('panier')) || [];
            panier.splice(index, 1);
            localStorage.setItem('panier', JSON.stringify(panier));
            afficherPanier();
        }

        function modifierQuantité(index, nouvelleQuantité) {
            let panier = JSON.parse(localStorage.getItem('panier')) || [];
            if (nouvelleQuantité <= 0) {
                panier.splice(index, 1);
            } else {
                panier[index].quantité = nouvelleQuantité;
            }
            localStorage.setItem('panier', JSON.stringify(panier));
            afficherPanier();
        }

        document.addEventListener('DOMContentLoaded', afficherPanier);
    </script>